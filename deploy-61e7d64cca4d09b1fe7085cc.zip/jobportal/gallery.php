<div style="width:730px; height:70px; border:solid 0px #CCCCCC;">
<div class="galleryDiv">

<script type="text/javascript">
			var leftrightslide = new Array();
					leftrightslide[0]='<a>  <img src="image/1.jpg" style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[1]='<a   <img src="image/2.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[2]='<a>  <img src="image/3.jpg"   style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[3]='<a>  <img src="image/4.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[4]='<a>  <img src="image/5.jpg"   style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[5]='<a>  <img src="image/6.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[6]='<a>  <img src="image/7.jpg"   style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[7]='<a>  <img src="image/8.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[8]='<a>  <img src="image/9.jpg" style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[9]='<a>  <img src="image/10.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[10]='<a> <img src="image/11.jpg" style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[11]='<a> <img src="image/12.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[12]='<a> <img src="image/13.jpg"   style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[13]='<a> <img src="image/14.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[14]='<a> <img src="image/15.jpg"   style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[15]='<a> <img src="image/16.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[16]='<a> <img src="image/17.jpg"   style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[17]='<a> <img src="image/18.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[18]='<a> <img src="image/19.jpg" style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[19]='<a> <img src="image/20.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[20]='<a> <img src="image/21.jpg"  style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[21]='<a> <img src="image/22.jpg" style="padding-right:10px; background:none;" /></a>' 
					leftrightslide[22]='<a> <img src="image/23.jpg"  style="padding-right:10px; background:none;" /></a>' 
		</script>	
		
		

<script type="text/javascript" src="clients.js"></script>

<span id="temp" style="visibility:hidden;position:absolute;top:-100px;left:-9000px">

<nobr><a> <img src="image/1.jpg" style="padding-right:10px; background:none;" /></a> 
					<a>  <img src="image/2.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/3.jpg" style="padding-right:10px; background:none;" /></a>
					<a> <img src="image/4.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/5.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/6.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/7.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/8.jpg" style="padding-right:10px; background:none;" /></a>
					<a> <img src="image/9.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/10.jpg"style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/11.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/12.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/13.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/14.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/15.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/16.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/17.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/18.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/19.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/20.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/21.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/22.jpg" style="padding-right:10px; background:none;" /></a> 
					<a> <img src="image/23.jpg" style="padding-right:10px; background:none;" /></a> 
</span>

 
</div></div>
	