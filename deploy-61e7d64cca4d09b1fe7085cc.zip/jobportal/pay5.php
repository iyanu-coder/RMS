<?php session_start(); ?>
<?php
	$ord=$_SESSION['ORDER_ID'];
	$fgt=$_SESSION['FGT'];
//	echo"$ord" . '<br />';
//	echo"$fgt";
?>
<HTML>
<HEAD>
<TITLE>E-Billing Solutions Pvt Ltd - Payment Page</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<style>
	h1       { font-family:Arial,sans-serif; font-size:24pt; color:#08185A; font-weight:100; margin-bottom:0.1em}
    h2.co    { font-family:Arial,sans-serif; font-size:24pt; color:#FFFFFF; margin-top:0.1em; margin-bottom:0.1em; font-weight:100}
    h3.co    { font-family:Arial,sans-serif; font-size:16pt; color:#000000; margin-top:0.1em; margin-bottom:0.1em; font-weight:100}
    h3       { font-family:Arial,sans-serif; font-size:16pt; color:#08185A; margin-top:0.1em; margin-bottom:0.1em; font-weight:100}
    body     {
	font-family:Verdana,Arial,sans-serif;
	font-size:11px;
	color:#08185A;
	background-color: #FFFFFF;
}
	th 		 { font-size:12px;background:#015289;color:#FFFFFF;font-weight:bold;height:30px;}
	td 		 { font-size:12px;background:#DDE8F3}
	.pageTitle { font-size:24px;}
.style2 {color: #FFFFFF}
a:link {
	color: #FFFFFF;
}
body,td,th {
	color: #003399;
}
.style10 {color: #FFFFFF; font-style: italic; }
.style11 {font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF;}
</style>
</HEAD>

</script>
<BODY LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 >
<center>

 <table width='100%' cellpadding='0' cellspacing="0" ><tr><th width='90%'><h2 class='co'>&nbsp;PHPGURUKUL Job Portal</h2></th></tr></table>
     <center>
<!--    <h1> Example</H1>
     </center>
  <center>
	   <table width="2" height="28" border="0" cellpadding="2" cellspacing="2">
       </table>
	   <h3> EBS Required Details</H3>
	   <table width="600" border="0" cellpadding="2" cellspacing="2">
         <tr>
           <th colspan="2"><span class="style2">FOR ANY QUERIES,KINDLY BROWSE</span> <span class="style2">OUR KNOWLEDGEBASE </span><span class="style10"><a href="http://support.ebs.in/index.php?_m=knowledgebase&_a=view" target="_ blank" class="style11" >CLICK HERE</a></span></th>
         </tr>
       </table>
  <table width="600" height="35" border="0" cellpadding="2" cellspacing="2">
         <tr>
           <th height="53" colspan="2"><div align="center"><span class="style2">Account Details</span></div></th>
         </tr>
       </table>  -->
  </center>
<form  method="post" action="" name="frmTransaction" id="frmTransaction" onSubmit="return validate()">
 
  <tr>
    <td class="fieldName"><span class="error">*</span>Order Completed</td>
    <td align="left">

  </tr>
  
    </table>
</form>
</center>
</table>
</body>
</html>